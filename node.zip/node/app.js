const log = require('./logger');

log('message');